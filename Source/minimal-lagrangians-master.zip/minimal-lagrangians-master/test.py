#!/usr/bin/env python3
import unittest
import terms
from data import *
from models import *

SCALAR_SINGLET  = ScalarField ('ss', 1, 0, z2=1)
SCALAR_DOUBLET  = ScalarField ('sd', 2, 0, z2=1)
SCALAR_TRIPLET  = ScalarField ('st', 3, 0, z2=1)
FERMION_SINGLET = FermionField('fs', 1, 0, z2=1)
FERMION_DOUBLET = FermionField('fd', 2, 0, z2=1)
FERMION_TRIPLET = FermionField('ft', 3, 0, z2=1)

IT = terms.InvariantTerm

MODELS = [model.implement(alpha) for model in DATA.values()
	for alpha in model.param_values]
MODELS += [model for model in DATA.values() if not model.param_values]

class Test(unittest.TestCase):
	@classmethod
	def setUpClass(cls):
		cls.lagrangians = {model: model.lagrangian() for model in MODELS}

	def test_InvariantTerm_adjoint(self):
		SS1 = SCALAR_SINGLET.attr(symbol='ss1')
		SS2 = SCALAR_SINGLET.attr(symbol='ss2')
		SD1 = SCALAR_DOUBLET.attr(symbol='sd1').attr(hypercharge=1)
		SD2 = SCALAR_DOUBLET.attr(symbol='sd2').attr(hypercharge=-1)
		self.assertEqual(IT([SS1, SS2]).adjoint, IT([SS1, SS2]))
		self.assertEqual(IT([SD1, SD2]).adjoint.adjoint, IT([SD1, SD2]))
		self.assertEqual(
			IT([SD1, SD2], [SS1]).adjoint, IT([SD2.adjoint, SD1.adjoint], [SS1])
		)
		self.assertNotEqual(IT([SD1, SD2]).adjoint, IT([SD1, SD2]))

	def test_InvariantTerm_eq(self):
		H = STANDARD_MODEL.get_field('H')
		H_a = H.adjoint
		T1_1_A_0 = DATA['T1-1-A'].implement(0)
		φ, ϕ_ = T1_1_A_0.get_field('φ', "ϕ'")
		ϕ__a = ϕ_.adjoint
		ST1 = SCALAR_TRIPLET.attr(symbol='s1')
		ST2 = SCALAR_TRIPLET.attr(symbol='s2')
		ST3 = SCALAR_TRIPLET.attr(symbol='s3')
		ST4 = SCALAR_TRIPLET.attr(symbol='s4')
		# singlets
		self.assertEqual(IT([φ, φ, φ]), IT([φ], [φ, φ]))
		self.assertEqual(IT([φ, φ, φ]), IT([φ, φ], [φ]))
		self.assertEqual(IT([φ, φ, φ]), IT([φ], [φ], [φ]))
		self.assertNotEqual(IT([φ, φ, φ, φ]), IT([φ, φ]))
		# doublets
		self.assertEqual(IT([H, ϕ_], [φ, φ]), IT([ϕ_, H], [φ, φ]))
		self.assertEqual(IT([H, ϕ_], [φ, φ]), IT([φ, φ], [ϕ_, H]))
		self.assertEqual(IT([H, ϕ_], [H, ϕ_]), IT([H, ϕ_], [ϕ_, H]))
		self.assertEqual(IT([H, ϕ_], [H, ϕ_]), IT([ϕ_, H], [H, ϕ_]))
		self.assertEqual(IT([H, ϕ_], [H, ϕ_]), IT([ϕ_, H], [ϕ_, H]))
		self.assertEqual(IT([H_a, ϕ__a], [H, ϕ_]), IT([ϕ__a, H_a], [H, ϕ_]))
		self.assertEqual(IT([H_a, ϕ__a], [H, ϕ_]), IT([H, ϕ_], [ϕ__a, H_a]))
		# triplets
		self.assertEqual(IT([ST1, ST2, ST3]), IT([ST2, ST3, ST1]))
		self.assertEqual(IT([ST1, ST2, ST3]), IT([ST3, ST1, ST2]))
		self.assertNotEqual(IT([ST1, ST2, ST3]), IT([ST3, ST2, ST1]))
		self.assertEqual(IT([ST1, ST2, ST3, ST4]), IT([ST2, ST3, ST4, ST1]))
		self.assertEqual(IT([ST1, ST2, ST3, ST4]), IT([ST3, ST4, ST1, ST2]))
		self.assertEqual(IT([ST1, ST2, ST3, ST4]), IT([ST4, ST1, ST2, ST3]))
		self.assertNotEqual(IT([ST1, ST2, ST3, ST4]), IT([ST1, ST3, ST2, ST4]))

	def test_InvariantTerm_hash(self):
		for model, L in self.lagrangians.items():
			for term in L:
				adjoint = term.adjoint
				if adjoint == term:
					self.assertEqual(hash(adjoint), hash(term),
						'{}: {} ≠ {}'.format(model.name, str(adjoint), str(term))
						+ str(term._counter)
					)

	# iter(InvariantTerm) should have a consistent order
	def test_InvariantTerm_iter(self):
		SD1 = SCALAR_DOUBLET.attr(symbol='sd1').attr(hypercharge=1)
		SD2 = SCALAR_DOUBLET.attr(symbol='sd2').attr(hypercharge=-1)
		term = IT([SD1.adjoint, SD1], [SD2.adjoint, SD2])
		self.assertEqual(tuple(term.adjoint), tuple(term))
		# check all model terms
		for model, L in self.lagrangians.items():
			for term in L:
				adjoint = term.adjoint
				if adjoint == term:
					self.assertEqual(tuple(adjoint), tuple(term),
						'{}: {} ≠ {}'.format(model.name, str(adjoint), str(term))
					)

	def test_Model_is_valid(self):
		SS = SCALAR_SINGLET
		SD = SCALAR_DOUBLET
		ST = SCALAR_TRIPLET
		FS = FERMION_SINGLET
		FD = FERMION_DOUBLET
		FT = FERMION_TRIPLET
		self.assertFalse(Model.is_valid(
			[FS, FS.adjoint]
		))
		self.assertTrue(Model.is_valid(
			[SD, SD]
		))
		self.assertTrue(Model.is_valid(
			[ST, ST]
		))
		self.assertTrue(Model.is_valid(
			[FD, FD]
		))
		self.assertTrue(Model.is_valid(
			[FT, FT]
		))
		self.assertFalse(Model.is_valid(
			[SD.attr(hypercharge=2), SD.attr(hypercharge=2)]
		))
		self.assertTrue(Model.is_valid(
			[SD, SD, SS, SS]
		))
		self.assertTrue(Model.is_valid(
			[SD, ST, SD, SS]
		))
		self.assertFalse(Model.is_valid(
			[SD, ST, SD, SD]
		))
		self.assertFalse(Model.is_valid(
			[ST, ST, ST, SS]
		))
		self.assertTrue(Model.is_valid(
			[SD, ST, ST, SD]
		))
		self.assertTrue(Model.is_valid(
			[ST, ST, ST, ST]
		))
		self.assertFalse(Model.is_valid(
			[ST, ST, FS]
		))
		self.assertTrue(Model.is_valid(
			[ST, FT, FS]
		))
		self.assertTrue(Model.is_valid(
			[SS, FS, FS]
		))
		self.assertFalse(Model.is_valid(
			[SS.attr(z2=-1), FS.attr(z2=-1), FS.attr(z2=-1)]
		))

	def test_BSMModel_lagrangian(self):
		H, L = STANDARD_MODEL.get_field('H', 'L')
		# test T1-1-A for α = 0
		T1_1_A_0 = DATA['T1-1-A'].implement(0)
		LL = T1_1_A_0.lagrangian()
		φ, ϕ_, ψ = T1_1_A_0.get_field('φ', "ϕ'", 'ψ')
		# LL should contain 17 terms for T1-1-A (α = 0)
		self.assertEqual(len(LL), 17)
		# mass terms
		self.assertIn(IT([ϕ_.adjoint, ϕ_]), LL)
		self.assertIn(IT([φ, φ]), LL)
		self.assertIn(IT([ψ, ψ]), LL)
		self.assertIn(IT([ψ.adjoint, ψ.adjoint]), LL)
		# pure scalar interaction terms
		# 3 scalars
		self.assertIn(IT([H, ϕ_], [φ]), LL)
		self.assertIn(IT([H.adjoint, ϕ_.adjoint], [φ]), LL)
		# 4 scalars
		self.assertIn(IT([H, ϕ_], [H, ϕ_]), LL)
		self.assertIn(IT([H.adjoint, ϕ_.adjoint], [H, ϕ_]), LL)
		self.assertIn(IT([H.adjoint, ϕ_.adjoint], [H.adjoint, ϕ_.adjoint]), LL)
		self.assertIn(IT([H.adjoint, H], [ϕ_.adjoint, ϕ_]), LL)
		# XXX The term |H^† ϕ'|² = (H^† ϕ') ((ϕ')^† H) does not appear in
		# https://arxiv.org/abs/0908.3729v2
		# It is redundant with other terms with respect to the parameter space,
		# but it is still a valid term.
		self.assertIn(IT([H.adjoint, ϕ_], [H, ϕ_.adjoint]), LL)
		self.assertIn(IT([ϕ_.adjoint, ϕ_], [ϕ_.adjoint, ϕ_]), LL)
		self.assertIn(IT([H.adjoint, H], [φ, φ]), LL)
		self.assertIn(IT([ϕ_.adjoint, ϕ_], [φ, φ]), LL)
		self.assertIn(IT([φ, φ, φ, φ]), LL)
		# Yukawa terms
		self.assertIn(IT([ϕ_.adjoint, L], [ψ]), LL)
		self.assertIn(IT([L.adjoint, ϕ_], [ψ.adjoint]), LL)

		# test the Higgs triplet model, see e.g.
		# https://arxiv.org/abs/1704.01162
		Higgs_triplet = DATA['Higgs-triplet']
		Δ = Higgs_triplet.get_field('Δ')
		LL = Higgs_triplet.lagrangian()
		# LL should contain 9 terms for the Higgs triplet model
		self.assertEqual(len(LL), 9)
		# mass term
		self.assertIn(IT([Δ.adjoint, Δ]), LL)
		# 3 scalars
		self.assertIn(IT([H, Δ.adjoint, H]), LL)
		self.assertIn(IT([H.adjoint, Δ, H.adjoint]), LL)
		# 4 scalars
		self.assertIn(IT([Δ.adjoint, Δ], [Δ.adjoint, Δ]), LL)
		self.assertIn(IT([Δ.adjoint, Δ, Δ.adjoint, Δ]), LL)
		self.assertIn(IT([H.adjoint, H], [Δ.adjoint, Δ]), LL)
		self.assertIn(IT([H.adjoint, Δ.adjoint, Δ, H]), LL)
		# Yukawa terms
		self.assertIn(IT([L, Δ, L]), LL)
		self.assertIn(IT([L.adjoint, Δ.adjoint, L.adjoint]), LL)

		# test models from https://arxiv.org/abs/1311.5896v1
		# Model A: singlet-doublet fermion
		SDF = DATA['SDF']
		LL = SDF.lagrangian()
		S, D1, D2 = SDF.get_field('S', 'D_1', 'D_2')
		# LL should contain 8 terms for the singlet-doublet fermion model
		self.assertEqual(len(LL), 8)
		# mass terms
		self.assertIn(IT([S, S]), LL)
		self.assertIn(IT([S.adjoint, S.adjoint]), LL)
		self.assertIn(IT([D1, D2]), LL)
		self.assertIn(IT([D1.adjoint, D2.adjoint]), LL)
		# Yukawa terms
		self.assertIn(IT([H, D1], [S]), LL)
		self.assertIn(IT([H.adjoint, D1.adjoint], [S.adjoint]), LL)
		self.assertIn(IT([H.adjoint, D2], [S]), LL)
		self.assertIn(IT([H, D2.adjoint], [S.adjoint]), LL)
		# Model B: singlet-doublet scalar
		SDS = DATA['SDS']
		LL = SDS.lagrangian()
		S, D = SDS.get_field('S', 'D')
		# LL should contain 9 + 1 + 3 = 13 terms for the singlet-doublet scalar model
		self.assertEqual(len(LL), 13)
		# mass terms
		self.assertIn(IT([S, S]), LL)
		self.assertIn(IT([D.adjoint, D]), LL)
		# 3 scalars
		self.assertIn(IT([D.adjoint, H], [S]), LL)
		self.assertIn(IT([H.adjoint, D], [S]), LL)
		# 4 scalars
		self.assertIn(IT([H.adjoint, H], [S, S]), LL)
		self.assertIn(IT([D.adjoint, D], [H.adjoint, H]), LL)
		self.assertIn(IT([D.adjoint, H], [H.adjoint, D]), LL)
		self.assertIn(IT([D.adjoint, H], [D.adjoint, H]), LL)
		self.assertIn(IT([H.adjoint, D], [H.adjoint, D]), LL)
		# The term |H D|² = (H^† D^†) (H D) does not appear in the paper
		# It is redundant with other terms with respect to the parameter space,
		# but it is still a valid term.
		self.assertIn(IT([H.adjoint, D.adjoint], [H, D]), LL)
		# the paper omits DM self-interactions, which are included here
		self.assertIn(IT([D.adjoint, D], [D.adjoint, D]), LL)
		self.assertIn(IT([D.adjoint, D], [S, S]), LL)
		self.assertIn(IT([S, S, S, S]), LL)
		# Model C: singlet-triplet scalar
		STS = DATA['STS']
		LL = STS.lagrangian()
		S, T = STS.get_field('S', 'T')
		# LL should contain 5 + 1 + 3 = 9 terms for the singlet-triplet scalar model
		self.assertEqual(len(LL), 9)
		# mass terms
		self.assertIn(IT([S, S]), LL)
		self.assertIn(IT([T, T]), LL)
		# 4 scalars
		self.assertIn(IT([H.adjoint, H], [S, S]), LL)
		self.assertIn(IT([H.adjoint, H], [T, T]), LL)
		self.assertIn(IT([H.adjoint, T, H], [S]), LL)
		# XXX The term H^† T² H does not appear in the paper.
		# It is proportional to the term H^† H Tr(T²), but this is not detected at
		# the moment.
		self.assertIn(IT([H.adjoint, T, T, H]), LL)
		# the paper omits DM self-interactions, which are included here
		self.assertIn(IT([T, T], [S, S]), LL)
		self.assertIn(IT([T, T, T, T]), LL)
		self.assertIn(IT([S, S, S, S]), LL)

if __name__ == '__main__':
	unittest.main()

