import functools
import itertools
import operator
from fractions import Fraction
from fields import *
from terms import *

class Model:
	def __init__(self, name, fields):
		self.name = name
		self.fields = fields = tuple(fields)
		self.scalars = tuple(x for x in fields if x.scalar)
		self.fermions = tuple(x for x in fields if x.fermion)
		# check for allowed attribute values
		for field in fields:
			assert field.type in ('S', 'F')
			assert field.su2_multiplicity in (1, 2, 3)
			assert field.z2 in (-1, 1)
		# check that there are no duplicate names
		msg = 'Some fields in model {} have duplicate names!'.format(self.name)
		assert len({f.symbol for f in fields}) == len(fields), msg
		assert len({f.sarah_symbol if hasattr(f, 'sarah_symbol') else f.symbol
			for f in fields
		}) == len(fields), msg

	def get_field(self, *symbols):
		result = [field for symbol in symbols for field in self.fields
			if symbol == field.symbol]
		if len(result) != len(symbols):
			raise ValueError('Field(s) not found: {}'.format(symbols))
		if len(result) == 1:
			return result[0]
		else:
			return result

	def term_from_symbols(self, *parts):
		return tuple(tuple(self.get_field(symbol) for symbol in tup)
			for tup in parts)

	@staticmethod
	def is_valid(term_comb):
		if not TermTypes.from_term_comb(term_comb, no_exception=True):
			return False
		# Lorentz invariance: must have an even number of left- and right-handed Weyl
		# spinors
		weyl_num_l = sum(x.fermion and not x.is_adjoint for x in term_comb)
		weyl_num_r = sum(x.fermion and x.is_adjoint for x in term_comb)
		lorentz_scalar = (weyl_num_l % 2 == 0) and (weyl_num_r % 2 == 0)
		# gauge invariance: SU(2), U(1), ℤ₂
		y_total = sum(x.hypercharge for x in term_comb)
		z2_total = functools.reduce(operator.mul, [x.z2 for x in term_comb], 1)
		index_counts = [x.su2_multiplicity - 1 for x in term_comb]
		indices_sum = sum(index_counts)
		index_counts += [-c for c in index_counts]
		su2_scalar = any(sum(comb) == 0
			for comb in itertools.combinations(index_counts, len(term_comb))
			if sum(abs(c) for c in comb) == indices_sum
		)
		return lorentz_scalar and su2_scalar and y_total == 0 and z2_total == 1

	@staticmethod
	# returns a list of InvariantTerms
	def generate_terms(term_comb):
		term_type = TermTypes.from_term_comb(term_comb)
		singlets = tuple(sorted([x for x in term_comb if x.su2_singlet],
			key=lambda x: not x.is_adjoint))
		doublets = tuple(sorted([x for x in term_comb if x.su2_doublet],
			key=lambda x: not x.is_adjoint))
		triplets = tuple(sorted([x for x in term_comb if x.su2_triplet],
			key=lambda x: not x.is_adjoint))
		if term_type in (TermTypes.S3, TermTypes.S4, TermTypes.YUKAWA):
			# 3 or 4 singlets
			if len(singlets) == len(term_comb):
				return [InvariantTerm(singlets)]
			# other terms with singlets
			elif singlets:
				# 2 doublets and 1 or 2 singlets
				if len(doublets) == 2 and not triplets:
					# SU(2) inner product (φ^a φ_a) is zero for scalars!
					if all(f.scalar for f in doublets) and doublets[0] == doublets[1]:
						return []
					else:
						return [InvariantTerm(doublets, singlets)]
				# 1 triplet, 2 doublets and 1 singlet
				elif len(doublets) == 2 and triplets:
					# only need to use D0 T D1 because D0 T D1 = ±D1 T D0
					return [InvariantTerm(
						(doublets[0],) + triplets + (doublets[1],), singlets
					)]
				# (2 triplets and 2 singlets) or (3 triplets and 1 singlet)
				elif len(triplets) >= 2:
					# use set to get unique permutations
					perms = {perm for perm in itertools.permutations(triplets)}
					return [InvariantTerm(perm, singlets) for perm in perms]
				else:
					raise ValueError('Invalid term combination: {}'.format(term_comb))
			# 4 doublets
			elif len(doublets) == len(term_comb) == 4:
				# use sets to get unique permutations
				perms = {InvariantTerm(perm[:2], perm[2:])
					for perm in itertools.permutations(doublets)}
				terms = [term for term in perms
					# SU(2) inner product (φ^a φ_a) is zero for scalars!
					if not any(prod[0] == prod[1] for prod in term)]
				return terms
			# 3 triplets
			elif len(triplets) == len(term_comb) == 3:
				# use set to get unique permutations
				terms = {InvariantTerm(perm)
					for perm in itertools.permutations(triplets)}
				return list(terms)
			# 4 triplets
			elif len(triplets) == len(term_comb) == 4:
				# use set to get unique permutations
				# trace of four triplets
				perm_4 = {InvariantTerm(perm)
					for perm in itertools.permutations(triplets)}
				# two traces of two triplets each
				perm_2 = {InvariantTerm(perm[0:2], perm[2:4])
					for perm in itertools.permutations(triplets)}
				# keep only the terms Tr(Δ^† Δ)² and Tr((Δ^† Δ)²)
				perm_2 -= {term
					for term in perm_2
					if all(T.symbol == term.fields[0].symbol for T in term.fields)
				}
				perm_2 |= {InvariantTerm([T.adjoint, T], [T.adjoint, T])
					for T in triplets}
				perm_4 -= {term
					for term in perm_4
					if all(T.symbol == term.fields[0].symbol for T in term.fields)
				}
				perm_4 |= {InvariantTerm([T.adjoint, T, T.adjoint, T])
					for T in triplets if not T.is_adjoint}
				# for real triplets, Tr(T²)² = 2 Tr(T⁴)
				perm_2 -= {InvariantTerm([T, T], [T, T])
					for T in triplets if T.adjoint == T}
				return list(perm_4 | perm_2)
			# (3 doublets, ≤1 triplet) and (1 doublet, 3 triplets) is not possible
			# only remaining combinations: 2 doublets and 1 or 2 triplets
			elif len(doublets) == 2 and len(triplets) > 0:
				doublet_perms = itertools.permutations(doublets)
				triplet_perms = itertools.permutations(triplets)
				candidates = list(itertools.product(doublet_perms, triplet_perms))
				# use set to get unique permutations
				# terms of the form D T D or D T² D
				terms = {InvariantTerm((cand[0][0],) + cand[1] + (cand[0][1],))
					for cand in candidates}
				# terms of the form D² Tr(T²)
				if len(triplets) == 2:
					terms |= {InvariantTerm(cand[0], cand[1])
						for cand in candidates}
				return list(terms)
			else:
				raise ValueError('Invalid term combination: {}'.format(term_comb))
		# mass terms
		else:
			# SU(2) inner product (φ^a φ_a) is zero for scalars!
			if doublets and all(f.scalar for f in doublets) and (
				doublets[0] == doublets[1]
			):
				return []
			else:
				return [InvariantTerm(term_comb)]

STANDARD_MODEL = Model('Standard Model', (
	ScalarField ('H',     2, Y= 1,               z2=1),
	FermionField('L',     2, Y=-1,               z2=1),
	FermionField('Q',     2, Y=Fraction(' 1/3'), z2=1),
	FermionField('e_R^c', 1, Y= 2,               z2=1),
	FermionField('u_R^c', 1, Y=Fraction('-4/3'), z2=1),
	FermionField('d_R^c', 1, Y=Fraction(' 2/3'), z2=1),
))
# add special names for some Standard Model fields in SARAH output
STANDARD_MODEL.get_field('L').sarah_symbol = 'l'
STANDARD_MODEL.get_field('Q').sarah_symbol = 'q'
STANDARD_MODEL.get_field('e_R^c').sarah_symbol = 'e'
STANDARD_MODEL.get_field('u_R^c').sarah_symbol = 'u'
STANDARD_MODEL.get_field('d_R^c').sarah_symbol = 'd'

class BSMModel(Model):
	def __init__(self, name, fields, param_values=()):
		fields = tuple(f.attr(bsm=True) for f in fields)
		super().__init__(name, STANDARD_MODEL.fields + fields)
		self.param_values = tuple(param_values)
		self.original_name = name
		self.imp_param_value = None

	def implement(self, alpha):
		assert alpha in self.param_values
		# add α to hypercharges
		imp_fields = tuple(f.attr(hypercharge=f.Y + alpha)
			for f in self.fields if f.bsm)
		# remove scalar fields which are equivalent to others
		filtered_fields = []
		for candidate in imp_fields:
			if candidate.fermion or not any(chosen.is_equivalent(candidate)
				for chosen in filtered_fields
			):
				filtered_fields.append(candidate)
		# check if fermions need to be made vector-like to cancel anomalies
		filtered_scalars = [f for f in filtered_fields if f.scalar]
		filtered_fermions_neutral = [f for f in filtered_fields
			if f.fermion and f.Y == 0]
		filtered_fermions_charged = [f for f in filtered_fields
			if f.fermion and f.Y != 0]
		# Some fermions must be vector-like if the total hypercharge does not
		# sum to zero. Note that this check could be more fine-grained: Any
		# existing pair of fermions with opposite hypercharges does not need to
		# be made vector-like. However, such cases (with sum(Y) ≠ 0, but a pair
		# of fermions with opposite Y) are only possible for topology T1-3
		# (whose models have three fermions), and none of the viable models
		# fall into this category.
		if sum(f.Y for f in filtered_fermions_charged) != 0:
			filtered_fields = (filtered_scalars + filtered_fermions_neutral +
				[weyl_fermion
					for f in filtered_fermions_charged
					for weyl_fermion in VectorLikeFermionField.from_field(f)]
			)
		# create and return result object
		result = BSMModel('{} (α = {})'.format(self.name, alpha), filtered_fields)
		result.original_name = self.name
		result.imp_param_value = alpha
		return result

	def lagrangian(self, omit_sm=True):
		term_combs = []
		scalars = tuple(s.adjoint for s in self.scalars
			if s.adjoint != s) + self.scalars
		fermions = tuple(f.adjoint for f in self.fermions
			if f.adjoint != f) + self.fermions
		fields = scalars + fermions
		for num_total in range(2, MASS_DIMENSION_MAX + 1):
			candidates = itertools.combinations_with_replacement(
				fields, num_total
			)
			term_combs += [term_comb for term_comb in candidates
				if Model.is_valid(term_comb)]
		# exclude pure Standard Model terms
		if omit_sm:
			term_combs = [comb for comb in term_combs if any(f.bsm for f in comb)]
		# generate proper terms from field combinations
		L = Lagrangian(
			term for comb in term_combs for term in Model.generate_terms(comb)
		)
		return L

