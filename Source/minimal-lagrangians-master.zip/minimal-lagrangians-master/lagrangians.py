#!/usr/bin/env python3
import argparse
import importlib
import pkgutil
import sys
import output
from data import *

output_modules = [info[1] for info in pkgutil.iter_modules(output.__path__)]
# parse command line arguments
parser = argparse.ArgumentParser(description='A Python program to generate the ' +
	'Lagrangians for minimal dark matter models with radiative neutrino masses')
parser.add_argument('model', metavar='model', choices=sorted(DATA.keys()),
	help='name of the model whose Lagrangian is to be generated')
parser.add_argument('alpha', metavar='parameter α', type=int, nargs='?',
	help='value of the model parameter α (determines hypercharges of the fields)')
parser.add_argument('--format', choices=output_modules, default='plain',
	help='output format for the generated Lagrangian (default: plain)')
parser.add_argument('--omit-self-interaction', action='store_true',
	help='omit pure self-interactions of the new fields in the Lagrangian, that ' +
		'is, output only interaction terms which involve both SM and new fields ' +
		'(default: output all terms)')

args = parser.parse_args()

# if a model with parameters has been selected, the parameter α must be specified
if DATA[args.model].param_values and args.alpha is None:
	parser.print_usage(file=sys.stderr)
	print('Error: The parameter α must be specified for model {}'.format(args.model),
		file=sys.stderr)
	sys.exit(2)

# create a dict of the models in data.py
models = [model.implement(alpha) for model in DATA.values()
	for alpha in model.param_values]
models += [model for model in DATA.values() if not model.param_values]
models = {model.name: model for model in models}

# format selected Lagrangian
param_values = DATA[args.model].param_values
if param_values:
	# print error message for wrong value of α
	if not args.alpha in param_values:
		print('Error: Invalid value for parameter α: {} (choose from {})'.format(
			args.alpha, param_values), file=sys.stderr)
		sys.exit(3)
	model = models['{} (α = {})'.format(args.model, args.alpha)]
else:
	model = models[args.model]

output_imp = importlib.import_module('output.{}'.format(args.format))
print(output_imp.Formatter.format_lagrangian(model, args.omit_self_interaction))

