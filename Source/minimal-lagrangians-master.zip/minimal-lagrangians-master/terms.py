import collections
import enum
import itertools
import output.plain

MASS_DIMENSION_MAX = 4
TermType = collections.namedtuple('TermType', 'num_scalars, num_fermions')
# bosons:   mass dimension = 1
# fermions: mass dimension = 3/2
# renormalizable if mass dimension of a term is ≤ 4
class TermTypes(enum.Enum):
	SCALAR_MASS  = TermType(2, 0)
	S3           = TermType(3, 0)
	S4           = TermType(4, 0)
	FERMION_MASS = TermType(0, 2)
	YUKAWA       = TermType(1, 2)

	@classmethod
	def from_term_comb(cls, term_comb, no_exception=False):
		num_scalars = sum(x.scalar for x in term_comb)
		num_fermions = sum(x.fermion for x in term_comb)
		term_type = TermType(num_scalars, num_fermions)
		for t in cls:
			if term_type == t.value:
				return t
		if no_exception:
			return False
		else:
			raise ValueError('Illegal term: {!r}'.format(term_comb))

	@property
	def mass_term(self):
		return self in (type(self).SCALAR_MASS, type(self).FERMION_MASS)

# returns True if l1 and l2 are cyclic rotations of each other, False otherwise
def is_cyclic_rotation(l1, l2):
	# if the lists have different length or contain different elements, return False
	if len(l1) != len(l2) or set(l1).difference(l2):
		return False
	l1, l2 = collections.deque(l1), collections.deque(l2)
	for i in range(len(l1)):
		l2.rotate()
		if l1 == l2:
			return True
	return False

# An InvariantProduct is essentially a tuple of fields representing a product
# of fields which is gauge-invariant.
# XXX move check for invariance to this class?
class InvariantProduct(tuple):
	def __new__(cls, fields):
		fields = list(fields)
		if len(fields) == 2:
			# sort fields by symbol
			fields.sort(key=lambda f: f.symbol)
			# bring fields in the order φ^† φ if possible
			if not fields[0].is_adjoint and fields[1].is_adjoint:
				fields.reverse()
		result = super().__new__(cls, fields)
		# use collections.Counter to represent a list where the order of
		# elements does not matter (“multiset”)
		# fields and its items need to be hashable (immutable) for this
		result._counter = collections.Counter(fields)
		result._hash = hash(frozenset(result._counter.items()))
		# assert that fields is not empty
		assert fields
		return result

	@property
	def adjoint(self):
		# taking the adjoint reverses the order of fields
		fields = [f.adjoint for f in reversed(self)]
		return type(self)(fields)

	def __eq__(self, other):
		if not isinstance(other, type(self)):
			return False
		self_triplets = [f for f in self if f.su2_triplet]
		other_triplets = [f for f in other if f.su2_triplet]
		# for terms with < 3 triplets, the order of fields does not matter
		if len(self_triplets) < 3:
			return self._counter == other._counter
		# terms with 3 or 4 triplets are invariant under cyclic permutations
		else:
			return is_cyclic_rotation(self_triplets, other_triplets)

	def __hash__(self):
		# for terms with < 3 triplets, the order of fields does not matter
		if sum(f.su2_triplet for f in self) < 3:
			return self._hash
		# return the same hash for all products of 3 or 4 triplets for simplicity
		else:
			return 0

	def __repr__(self):
		return 'InvariantProduct' + super().__repr__()

	def __str__(self):
		return output.plain.Formatter.format_product(self)

# An InvariantTerm is a list of InvariantProducts and represents a term in the
# Lagrangian. As it is a product of gauge-invariant products, it too is
# gauge-invariant. In addition, an InvariantTerm is also Lorentz-invariant, i.e. it
# contains an even number of both left- and right-handed fermion fields.
# The order of InvariantProducts within the term does not matter.
class InvariantTerm(tuple):
	def __new__(cls, *products):
		products = [
			p if isinstance(p, InvariantProduct) else InvariantProduct(p)
			for p in products
		]
		# sort products by string representation
		products.sort(key=lambda p: str(p))
		# sort products by SU(2) multiplicity (descending)
		products.sort(key=lambda p: -sum(f.su2_multiplicity for f in p))
		# sort products by length (descending)
		products.sort(key=lambda p: -len(p))
		# sort products by number of adjoint fields (descending)
		products.sort(key=lambda p: -sum(f.is_adjoint for f in p))
		# merge all products of scalar singlets with Y = 0 into one
		p_no_singlets = []
		p_singlets = []
		for prod in products:
			if all(x.scalar and x.su2_singlet and x.hypercharge == 0 for x in prod):
				p_singlets += prod
			else:
				p_no_singlets.append(prod)
		if p_singlets:
			singlets_product = InvariantProduct(p_singlets)
			products = tuple(p_no_singlets + [singlets_product])
		else:
			products = tuple(products)
		result = super().__new__(cls, products)
		result._fields = None
		# use collections.Counter to represent a list where the order of
		# elements does not matter (“multiset”)
		# products and its items need to be hashable (immutable) for this
		result._counter = collections.Counter(products)
		result._hash = hash(frozenset(result._counter.items()))
		# assert that products is not empty
		assert products
		return result

	@property
	def adjoint(self):
		# taking the adjoint reverses the order of fields
		products = [p.adjoint for p in reversed(self)]
		return type(self)(*products)

	@property
	def fields(self):
		if not self._fields:
			self._fields = tuple(field for prod in self for field in prod)
		return self._fields

	@property
	def term_type(self):
		return TermTypes.from_term_comb(self.fields)

	def __eq__(self, other):
		if not isinstance(other, type(self)):
			return False
		return self._counter == other._counter

	def __hash__(self):
		return self._hash

	def __repr__(self):
		return 'InvariantTerm' + super().__repr__()

	def __str__(self):
		return output.plain.Formatter.format_term(self)

# A Lagrangian is essentially a set of Term objects.
class Lagrangian(frozenset):
	# key function to group terms by type when sorting
	@staticmethod
	def sort_key(term):
		t_type = term.term_type
		offset = 0
		# put fermion terms at the end
		if t_type in (TermTypes.FERMION_MASS, TermTypes.YUKAWA):
			offset += 10
		return offset + sum(t_type.value)

	def __new__(cls, iterable):
		terms_in = [
			t if isinstance(t, InvariantTerm) else InvariantTerm(t)
			for t in iterable
		]
		terms = set(terms_in)
		# replace pairwise adjoint terms with one term which is also in add_hc
		add_hc = set()
		checked = set()
		# iterate over a copy of terms so that terms can be mutated during iteration
		for term in set(terms):
			adjoint = term.adjoint
			if adjoint in checked:
				terms.remove(term)
				terms.remove(adjoint)
				# keep the term with fewer adjoint fields
				term_adjnum = sum(f.is_adjoint for f in term.fields)
				adjoint_adjnum = sum(f.is_adjoint for f in adjoint.fields)
				keep = adjoint if adjoint_adjnum < term_adjnum else term
				terms.add(keep)
				# record terms whose adjoint should be included in add_hc
				add_hc.add(keep)
			checked.add(term)
		result = super().__new__(cls, terms)
		result.add_hc = frozenset(add_hc)
		# remember order of insertion to obtain reproducible iteration order between
		# several executions of the program
		lst = []
		seen = set()
		for term in terms_in:
			if term not in seen and term in terms:
				lst.append(term)
			seen.add(term)
		assert len(lst) == len(terms)
		result.list = lst
		# group terms in the Lagrangian
		result.list.sort(key=result.sort_key)
		return result

	def without_self_interaction(self):
		return type(self)(
			term for term in self
			if len(term.fields) == 2 or
				not all(field.bsm for field in term.fields)
		)

	def __contains__(self, item):
		return item.adjoint in self.add_hc or super().__contains__(item)

	def __iter__(self):
		# always group terms in the Lagrangian
		for term in self.list:
			yield term
			if term in self.add_hc:
				yield term.adjoint

	def __len__(self):
		# count terms with add_hc twice
		return super().__len__() + len(self.add_hc)

	def __repr__(self):
		return super().__repr__().replace('frozenset', 'Lagrangian', 1)

	def __str__(self):
		result, _ = output.plain.Formatter._format_lagrangian(None, self)
		return result

