# minimal-lagrangians
This is a Python program which allows one to specify the field content of an extension
of the Standard Model of particle physics and, using this information, generates the
most general renormalizable Lagrangian that describes such a model. As the program was
written for the study of minimal dark matter models with radiative neutrino masses,
it can handle additional fields with the following properties:
- scalar or Weyl fermion fields
- SU(3) singlets
- SU(2) singlets, doublets or triplets
- arbitrary hypercharge
- charged under a global ℤ₂ symmetry

## Requirements
The program requires Python 3 (tested with Python ≥ 3.4).

## Usage
The program only prints the potential involving at least one new (i. e. non-SM) field,
i. e. the kinetic terms and the Standard Model Lagrangian are omitted. The models are
not checked for anomalies (tools like SARAH can be used for this purpose).

The new models are currently defined in the file [`data.py`](data.py). A model can be
added as an entry to the list in the following form:
```python
BSMModel('<model_name>', (
        # list of fields
        # type       name   SU(2) rep.  hypercharge
        # for a scalar field, e.g. a scalar doublet with hypercharge 1:
        ScalarField ('S',   2,          Y=1),
        # for a fermion field, e.g. a fermion singlet with hypercharge 0:
        FermionField('F',   1,          Y=0),
        # …
    )
    # optional: parameter values for different hypercharge assignments (offsets), e.g.
    , (0, 2, …)
),
```

Information on how to run the program on the command line can be obtained with
`lagrangians.py -h`:
>     usage: lagrangians.py [-h] [--format {LaTeX,SARAH,plain}]
>                           [--omit-self-interaction]
>                           model [parameter α]
>     
>     A Python program to generate the Lagrangians for minimal dark matter models
>     with radiative neutrino masses
>     
>     positional arguments:
>       model                 name of the model whose Lagrangian is to be generated
>       parameter α           value of the model parameter α (determines
>                             hypercharges of the fields)
>     
>     optional arguments:
>       -h, --help            show this help message and exit
>       --format {LaTeX,SARAH,plain}
>                             output format for the generated Lagrangian (default:
>                             plain)
>       --omit-self-interaction
>                             omit pure self-interactions of the new fields in the
>                             Lagrangian, that is, output only interaction terms
>                             which involve both SM and new fields (default: output
>                             all terms)

Test cases can be run using

    ./test.py

Among other checks, this currently tests whether the program produces the correct
Lagrangian for the following models:
- T1-1-A with α = 0, as given in [(Farzan; arXiv:0908.3729 [hep-ph])][1], which
  presents an implementation of this model.
- The models given in [(Cheung, Sanford; arXiv:1311.5896 [hep-ph])][3]:
  - singlet–doublet fermion model (SDF, “model A”)
  - singlet–doublet scalar model (SDS, “model B”)
  - singlet–triplet scalar model (STS, “model C”)
- The Higgs triplet model (→ seesaw type II), see e. g.
  [(Kanemura, Yagyu; arXiv:1201.6287 [hep-ph])][4].

## Examples
For example, running

    lagrangians.py T1-1-A 0

prints the Lagrangian for the model T1-1-A with α = 0 from
[(Restrepo, Zapata, Yaguna; arXiv:1308.3655 [hep-ph])][2]:
>      - m_ϕ' ϕ'^† ϕ' - ½ m_φ² φ²
>      - (λ₁ (H ϕ') φ + H.c.)
>      - λ₂ (H^† H) (ϕ'^† ϕ') - λ₃ (H^† ϕ'^†) (H ϕ') - λ₄ (H^† ϕ') (ϕ'^† H) - λ₅ (H^† H) φ² - λ₆ (ϕ'^† ϕ')² - λ₇ (ϕ'^† ϕ') φ² - (λ₈ (H ϕ')² + H.c.) - λ₉ φ⁴
>      - (½ m_ψ ψ ψ + H.c.)
>      - (λ₁₀ (ϕ'^† L) ψ + H.c.)

Running

    lagrangians.py STS

prints the Lagrangian for model C (singlet–triplet scalar) from
[(Cheung, Sanford; arXiv:1311.5896 [hep-ph])][3]:
>      - ½ m_S² S² - ½ m_T² Tr(T²)
>      - λ₁ (H^† H) S² - λ₂ (H^† T H) S - λ₃ H^† T² H - λ₄ (H^† H) Tr(T²) - λ₅ S⁴ - λ₆ Tr(T²) S² - λ₇ Tr(T⁴)

## Things to watch out for
- Currently, the parameters in SARAH output are numbered differently than in the other output formats.

## To-do list
- A number of identities allows one to remove some terms involving SU(2) doublets and
  triplets from the Lagrangian in certain circumstances because the parameter space is
  redundant in these cases. The removal of such redundant terms could be added.
- Add flag for mixing/no mixing in SARAH output.


[1]: https://arxiv.org/abs/0908.3729
[2]: https://arxiv.org/abs/1308.3655
[3]: https://arxiv.org/abs/1311.5896
[4]: https://arxiv.org/abs/1201.6287

