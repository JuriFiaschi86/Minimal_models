import collections
import copy
import output.plain
from fractions import Fraction

# type: 'S' or 'F' for scalar or (Weyl) fermion
#       Note that Weyl fermions are always assumed to be left-handed, i.e. in the
#       (½, 0) representation of SL(2, ℂ)
# su2_multiplicity: what representation of SU(2) the field is in (singlet, doublet,
#	triplet). Note that triplets are assumed to be in the adjoint representation
#	(“matrix form”).
# Y: value of the field’s hypercharge Y
# z2: value of the discrete ℤ₂ symmetry of the Lagrangian (1 or -1)
class Field:
	@staticmethod
	def from_field(field):
		return copy.copy(field)

	def __init__(self, symbol, type, su2_multiplicity, Y, z2=-1, is_adjoint=False):
		self.symbol = symbol
		self.type = type
		self.su2_multiplicity = su2_multiplicity
		self.hypercharge = Y
		self.z2 = z2
		self.is_adjoint = is_adjoint
		self.bsm = False

	@property
	def adjoint(self):
		# real scalar s: s^† = s
		# valid for real singlets and real triplets in matrix form
		if self.scalar and (self.su2_singlet or self.su2_triplet) and self.Y == 0:
			return self.from_field(self)
		return self.attr(
			is_adjoint=not self.is_adjoint, hypercharge=-self.hypercharge
		)

	@property
	def components(self):
		# SU(2) n-plet has n = 2j + 1 and T_3 = -j, …, j in integer steps
		n = self.su2_multiplicity
		j = Fraction(n - 1, 2)
		components = [FieldComponent(self, -j + i) for i in range(n)]
		components.reverse()
		# for real fields (e.g. triplets), (T^+)^† = T^-
		if self.adjoint == self:
			components[int(j + 1):] = [c.adjoint for c in components[:int(j + 0.5)]]
		assert len(components) == n
		return components

	@property
	def scalar(self):
		return self.type == 'S'

	@property
	def fermion(self):
		return self.type == 'F'

	@property
	def su2_singlet(self):
		return self.su2_multiplicity == 1

	@property
	def su2_doublet(self):
		return self.su2_multiplicity == 2

	@property
	def su2_triplet(self):
		return self.su2_multiplicity == 3

	@property
	def Y(self):
		return self.hypercharge

	def attr(self, **kw):
		cp = self.from_field(self)
		for key, val in kw.items():
			setattr(cp, key, val)
		return cp

	def is_equivalent(self, other):
		return self.type == other.type and \
			self.su2_multiplicity == other.su2_multiplicity and \
			abs(self.hypercharge) == abs(other.hypercharge) and \
			self.z2 == other.z2

	def __eq__(self, other):
		return self.is_equivalent(other) and \
			self.hypercharge == other.hypercharge and \
			self.is_adjoint == other.is_adjoint and \
			self.symbol == other.symbol

	def __hash__(self):
		return hash((self.symbol, self.su2_multiplicity, self.hypercharge))

	def __repr__(self):
		return ('Field({!r}, {!r}, {!r}, Y={!r}, z2={!r}, ' +
			'is_adjoint={!r})').format(
			self.symbol, self.type, self.su2_multiplicity, self.hypercharge,
			self.z2, self.is_adjoint
		)

	def __str__(self):
		return output.plain.Formatter.format_field(self)

# A ScalarField represents a Lorentz-scalar SU(2) multiplet.
class ScalarField(Field):
	def __init__(self, symbol, su2_multiplicity, Y, z2=-1, is_adjoint=False):
		super().__init__(symbol, 'S', su2_multiplicity, Y, z2, is_adjoint)

# A FermionField represents a Weyl fermion SU(2) multiplet.
class FermionField(Field):
	def __init__(self, symbol, su2_multiplicity, Y, z2=-1, is_adjoint=False):
		super().__init__(symbol, 'F', su2_multiplicity, Y, z2, is_adjoint)

# A DiracFermionField represents a Dirac fermion SU(2) multiplet.
DiracFermionField = collections.namedtuple('DiracFermionField',
	'left, right'
)

# A VectorLikeFermionField represents a vector-like Dirac fermion
# SU(2) multiplet, i.e. both the left-handed and the right-handed components
# of the Dirac fermion have the same quantum numbers.
class VectorLikeFermionField(DiracFermionField):
	def __new__(cls, symbol, su2_multiplicity, Y, z2=-1, is_adjoint=False):
		# left-handed Weyl spinor
		left = FermionField(symbol + '1', su2_multiplicity, Y, z2, is_adjoint)
		# (adjoint of the) right-handed Weyl spinor
		right = FermionField(symbol + '2', su2_multiplicity, -Y, z2, is_adjoint)
		result = super().__new__(cls, left, right.adjoint)
		return result

	@classmethod
	def from_field(cls, field):
		assert field.fermion
		return cls(field.symbol, field.su2_multiplicity, field.Y, field.z2,
			field.is_adjoint)

# A FieldComponent represents a component of an SU(2) multiplet.
class FieldComponent(Field):
	def __init__(self, field, T3):
		super().__init__(field.symbol, field.type, field.su2_multiplicity, field.Y,
			field.z2, field.is_adjoint)
		self.T3 = int(T3) if int(T3) == T3 else T3
		# set symbol
		charge = self.charge
		if charge > 0:
			suffix = abs(charge) * '+'
		elif charge < 0:
			suffix = abs(charge) * '-'
		else:
			suffix = '0'
		self.symbol = self.symbol + suffix

	@property
	def adjoint(self):
		adjoint = super().adjoint
		# components of real fields can still be complex
		if self.charge != 0:
			adjoint.T3 = -adjoint.T3
			adjoint.is_adjoint = not adjoint.is_adjoint
		return adjoint

	@property
	def charge(self):
		result = Fraction(Fraction(self.Y, 2)) + self.T3
		return int(result) if int(result) == result else result

	@property
	def components(self):
		return [self]

	def __str__(self):
		return output.plain.Formatter.format_field(self)

