#!/usr/bin/env wolframscript
(* get normal output formatting instead of script output (InputForm), see
https://reference.wolfram.com/language/tutorial/WolframLanguageScripts.html *)
(*SetOptions[$Output, FormatType -> OutputForm];*)
(* check command line *)
If[Length[$ScriptCommandLine] > 1,
    model = $ScriptCommandLine[[2]];,
    (* don’t overwrite “model” if it is already defined *)
    If[! ValueQ[model],
        model = "simon/T1-3-B_0";
        Print["Usage: sarah.m [model]"];
        Print["[model] not specified, using default: " <> model];,
        Null
    ];
];

<<"SARAH/SARAH.m";
Start[model];

WriteString[
    FileNameJoin[{"tmp", StringReplace[model, "/" -> "-"], "MODEL_NAME"}],
    Model`Name
];

MakeSPheno[StandardCompiler -> "gfortran", IncludeLoopDecays -> True];
(* CPViolation must be set to True if the model has complex parameters *)
MakeCHep[SLHAinput -> True, CPViolation -> False];
