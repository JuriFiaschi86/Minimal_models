#!/usr/bin/env python2
# -*- coding: utf-8 -*-
from __future__ import division, print_function
from six.moves import input, range
import argparse
import collections
import itertools
import math
import numbers
import operator
import os.path
import random
import re
import subprocess
import tempfile
import signal
import sys
import numpy
# pyslha (as of version 3.2.1) doesn’t (officially) support Python 3:
# http://www.insectnation.org/projects/pyslha
import pyslha
from functools import reduce

# terminate on SIGINT (e.g. pressing Ctrl-C)
def sigint_handler(signal, frame):
	print()
	sys.exit(0)
signal.signal(signal.SIGINT, sigint_handler)

def safe_eval(expression, locals):
	if '__' in expression:
		raise ValueError('Accessing reserved names is forbidden')
	return eval(expression, {'__builtins__': None}, locals)

class GetIndex(object):
	def __getitem__(self, idx): return idx
GET_INDEX = GetIndex()

class hashable_slice(tuple):
	def __new__(cls, slice):
		result = tuple.__new__(cls, (slice.start, slice.stop, slice.step))
		result.slice = slice
		return result

	def __getattr__(self, name):
		return getattr(self.slice, name)

Parameter = collections.namedtuple('Parameter', 'name, index')
def parse_param(param_str):
	# extract parameter name and possible index
	param = param_str.split('[')
	if len(param) == 1:
		param_name = param[0]
		index = None
	else:
		param_name, index_str = param
		index_gi = safe_eval('GI[' + index_str, {'GI': GET_INDEX})
		index_gi = index_gi if isinstance(index_gi, tuple) else (index_gi,)
		index = []
		for i in index_gi:
			if isinstance(i, slice):
				# adjust for one-based indexing
				if i.start is None or i.start < 1:
					index.append(hashable_slice(GET_INDEX[1:i.stop:i.step]))
				else:
					index.append(hashable_slice(i))
			else:
				if i == -1:
					index.append(hashable_slice(GET_INDEX[i:]))
				else:
					index.append(hashable_slice(GET_INDEX[i:i + 1]))
		index = tuple(index)
	return Parameter(param_name, index)

ScanOptions = collections.namedtuple('ScanOptions',
	'scan_type, param, options'
)

def scan_action(*types):
	_types = types
	# action arguments: <param> <scan_args…>
	class ScanAction(argparse.Action):
		types = _types
		def __call__(self, parser, namespace, values, option_string=None):
			if getattr(namespace, self.dest) is None:
				setattr(namespace, self.dest, [])
			types = self.types
			expected_len = len(types) + 1
			ellipsis = False
			if types[-1] is Ellipsis:
				assert len(types) > 1
				types = itertools.chain(types[:-1], itertools.repeat(types[-2]))
				ellipsis = True
			if not ellipsis and len(values) not in (
				expected_len, expected_len + 1
			):
				raise argparse.ArgumentError(self,
					'expected {} or {} arguments'.format(
						expected_len, expected_len + 1
					)
				)
			# convert types
			typeconv_values = ScanOptions(
				option_string, parse_param(values[0]),
				tuple(type(value) for type, value in zip(types, values[1:]))
			)
			getattr(namespace, self.dest).append(typeconv_values)
	return ScanAction

# command line arguments
parser = argparse.ArgumentParser(description='Generate SLHA input files '
	'for SPheno and run a parameter scan using micrOMEGAs')
parser.add_argument('model', nargs='?', default='T13Balpha0',
	help='the model name to use for the filenames')
parser.add_argument('--spheno-ver', default='4.0.3',
	help='the version of SPheno to be used')
parser.add_argument('--micromegas-ver', default='4.3.5',
	help='the version of micrOMEGAs to be used')
parser.add_argument('--micromegas-exe', default='main_t13b0',
	help='file name of the micrOMEGAs executable')
parser.add_argument('--tree-level', action='store_true',
	help='don’t calculate masses at loop level or run SM couplings')
parser.add_argument('--random-points', default=0,
	help='for random scans, generate a new random parameter value for all '
		'random parameters at each point (instead of only varying one '
		'parameter at a time while keeping the others fixed)')
parser.add_argument('--condition', action='append', default=[],
	help='specify a condition to be satisfied by all scanned parameter points')
parser.add_argument('--skip', type=int, default=0,
	help='skip the specified number of points during the scan (e.g. to resume '
		'an interrupted scan)')
parser.add_argument('--set', nargs='+', default=[], dest='param_scan',
	action=scan_action(float, Ellipsis),
	metavar=('param', 'values'),
	help='set a parameter to the fixed values given in a list')
parser.add_argument('--linear', nargs=4, default=[], dest='param_scan',
	action=scan_action(float, float, float),
	metavar=('param', 'start', 'stop', 'step'),
	help='vary a parameter with a fixed step size in the specified interval')
parser.add_argument('--linearN', nargs=4, default=[], dest='param_scan',
	action=scan_action(float, float, int),
	metavar=('param', 'start', 'stop', 'N'),
	help='generate N equidistant parameter values in the specified interval')
parser.add_argument('--exp', nargs=4, default=[], dest='param_scan',
	action=scan_action(float, float, float),
	metavar=('param', 'start', 'stop', 'step'),
	help='vary a parameter exponentially in the specified interval')
parser.add_argument('--expN', nargs=4, default=[], dest='param_scan',
	action=scan_action(float, float, int),
	metavar=('param', 'start', 'stop', 'N'),
	help='generate N exponentially increasing parameter values in the '
		'specified interval')
parser.add_argument('--random', nargs=4, default=[], dest='random_scan',
	action=scan_action(float, float, int),
	metavar=('param', 'low', 'high', 'N'),
	help='vary a parameter randomly (with a uniform probability distribution) '
		'in the specified interval')
parser.add_argument('--random-dist', nargs='+', default=[], dest='random_scan',
	action=scan_action(str, int, float, Ellipsis),
#	metavar=('param', 'distribution', 'N' 'dist_param'),
	metavar=('param', 'options'),
	help='vary a parameter randomly, with the specified probability '
		'distribution, in the specified interval')
args = parser.parse_args()
# dict of parameter-scanning arguments
if not args.random_points:
	args.param_scan += args.random_scan
	args.random_scan = []

class DerivedParameter:
	def __init__(self, name, affects, dependence, formula, value=0):
		self.name = name
		self.affects = tuple(affects)
		self.dependence = tuple(dependence)
		self.formula = formula
		self.value = value

	def param_values(self, dependence_input):
		return self.formula(self.value, *dependence_input)

class Model:
	def __init__(self, name, slha_doc, params, derived_params=()):
		self.name = name
		self.slha_doc = slha_doc
		self.params = params
		self.derived_params = {param.name: param for param in derived_params}

	def param_value(self, param):
		param_name, index = param
		block_name, block_index = self.params[param_name]
		block = self.slha_doc.blocks[block_name]
		if isinstance(block_index, numbers.Integral):
			assert index is None or index == block_index
			return block[block_index]
		else:
			assert len(index) == len(block_index)
			return block[index]

	def set_param_value(self, param, value):
		param_name, index = param
		blocks = self.slha_doc.blocks
		if param_name in self.derived_params:
			param = self.derived_params[param_name]
			indices = [self.params[slha_param] for slha_param in param.affects]
			values = param.param_values([self.derived_params[d_param].value
				for d_param in param.dependence
			])
		else:
			block_name, block_index = self.params[param_name]
			indices = [(block_name, block_index)]
			values = [value]
		for slha_pos, value in zip(indices, values):
			block_name, block_index = slha_pos
			if isinstance(block_index, numbers.Integral):
				assert index is None or index == block_index
				blocks[block_name][block_index] = value
			elif index is not None:
				assert len(index) == len(block_index)
				for m_index in itertools.product(*(
					# need to use idx_len + 1 because of one-based indexing
					range(*idx.indices(idx_len + 1))
					for idx, idx_len in zip(index, block_index)
				)):
					blocks[block_name][m_index] = value
			else:
				for m_index in itertools.product(
					*(range(1, dim + 1) for dim in block_index)
				):
					blocks[block_name][m_index] = value

MODEL_NAME = args.model
SPHENO_VERSION = args.spheno_ver
SPHENO_DIR = 'SPheno-' + SPHENO_VERSION
SPHENO_INPUT_FILE = 'LesHouches.in.{}_low'.format(MODEL_NAME)
SPHENO_OUTPUT_FILE = 'SPheno.spc.{}'.format(MODEL_NAME)
MICROMEGAS_VERSION = args.micromegas_ver
MICROMEGAS_DIR = 'micromegas_' + MICROMEGAS_VERSION
MICROMEGAS_EXE = args.micromegas_exe
RUN_INFO_FILE = 'parameter_scan_info.txt'
DOC = pyslha.read(os.path.join(SPHENO_DIR, 'input', SPHENO_INPUT_FILE),
	ignorenomass=True
)
# {variable name: (block, number)} (simple numbers) or
# {variable name: (block, (range1, range2, …))} (matrices)
# XXX determine parameter positions automatically (e.g. through SARAH?)
MODELS = [
	Model('T13Balpha0', DOC, {
			'lambda':   ('MINPAR', 1),
			'mphi':     ('MINPAR', 11),
			'mCPsi':    ('MINPAR', 12),
			'mpsipsip': ('MINPAR', 13),
			'lambda1':  ('MINPAR', 21),
			'lambda3':  ('MINPAR', 23),
			'lambda4':  ('MINPAR', 24),
			'lambda5':  ('MINPAR', 25),
			'lambda6':  ('LAM6IN', (3,)),
		}, [
			DerivedParameter('y', ['lambda4', 'lambda5'], ['tan_theta'],
				lambda y, tan_theta: (
					y * math.sin(math.atan(tan_theta)),
					y * math.cos(math.atan(tan_theta))
				)
			),
			DerivedParameter('tan_theta', ['lambda4', 'lambda5'], ['y'],
				lambda tan_theta, y: (
					y * math.sin(math.atan(tan_theta)),
					y * math.cos(math.atan(tan_theta))
				)
			),
		]
	),
	Model('T13Balpha02g', DOC, {
			'lambda':   ('MINPAR',  1),
			'mCPsi':    ('MINPAR',  12),
			'mpsipsip': ('MINPAR',  13),
			'lambda4':  ('MINPAR',  24),
			'lambda5':  ('MINPAR',  25),
			'mphi2':    ('MPHI2IN', (2, 2)),
			'lambda1':  ('LAM1IN',  (2, 2)),
			'lambda6':  ('LAM6IN',  (3, 2)),
		},
		[
			DerivedParameter('y', ['lambda4', 'lambda5'], ['tan_theta'],
				lambda y, tan_theta: (
					y * math.sin(math.atan(tan_theta)),
					y * math.cos(math.atan(tan_theta))
				)
			),
			DerivedParameter('tan_theta', ['lambda4', 'lambda5'], ['y'],
				lambda tan_theta, y: (
					y * math.sin(math.atan(tan_theta)),
					y * math.cos(math.atan(tan_theta))
				)
			),
		]
	),
	Model('CSSDF', DOC, {
			'lambda':   ('MINPAR', 1),
			'msing':    ('MINPAR', 12),
			'mdoub':    ('MINPAR', 13),
			'lambda1':  ('MINPAR', 21),
			'lambda2':  ('MINPAR', 22),
		}, [
			DerivedParameter('y', ['lambda2', 'lambda1'], ['tan_theta'],
				lambda y, tan_theta: (
					y * math.sin(math.atan(tan_theta)),
					y * math.cos(math.atan(tan_theta))
				)
			),
			DerivedParameter('tan_theta', ['lambda2', 'lambda1'], ['y'],
				lambda tan_theta, y: (
					y * math.sin(math.atan(tan_theta)),
					y * math.cos(math.atan(tan_theta))
				)
			),
		]
	),
	Model('sonja', DOC, {
			'mD':   ('NEWININ', 1),
			'mS':   ('NEWININ', 4),
			'yd1':  ('NEWININ', 2),
			'yd2':  ('NEWININ', 3),
		},
	),
]
MODELS = {model.name: model for model in MODELS}

# SLHA settings
blocks = DOC.blocks
spheno_input = blocks['SPHENOINPUT']
# set SPheno error level to 0 (print all warnings)
# XXX setting a higher error level (1 or 2) terminates SPheno immediately!
spheno_input[1] = 0
# output files for use with micrOMEGAs, see
# http://stauby.de/sarah_wiki/index.php?title=Flags_in_SPheno_LesHouches_file
# http://stauby.de/sarah_userforum/viewtopic.php?f=4&t=376
spheno_input[50] = 0
spheno_input[77] = 1
# enable/disable calculation of loop masses
spheno_input[55] = int(not args.tree_level)
# enable/disable running of SM parameters
spheno_input[61] = int(not args.tree_level)
# disable calculation of 3-body decays
spheno_input[13] = 0
# disable calculation of loop decays
spheno_input[16] = 0
# disable output of unnecessary files
spheno_input[75] = 0 # WHIZARD
spheno_input[76] = 0 # HiggsBounds
spheno_input[79] = 0 # WCXF
# disable output of unnecessary SLHA blocks
spheno_input[520] = 0 # HiggsBounds blocks
spheno_input[521] = 0 # diphoton/digluon widths
spheno_input[530] = 0 # Vevacious blocks

def points_in_range(start, stop, step):
	return round(abs((stop - start) / step)) + 1

def first_param_value(scan_opts):
	scan_type = scan_opts.scan_type
	param_args = scan_opts.options
	if scan_type in ('--set', '--linear', '--linearN', '--exp', '--expN'):
		return param_args[0]
	elif scan_type == '--random':
		low, high, count = param_args
		return random.uniform(low, high)
	elif scan_type == '--random-dist':
		dist_name, count = param_args[:2]
		dist_args = param_args[2:]
		return getattr(random, dist_name)(*dist_args)
	else:
		raise ValueError('Unknown scan type')

def param_values(params):
	for param, scan_opts_list in params.items():
		for scan_opts in scan_opts_list:
			scan_type = scan_opts.scan_type
			param_args = scan_opts.options
			# fixed values
			if scan_type == '--set':
				for value in param_args:
					yield param, value
			# linear scan
			elif scan_type == '--linear':
				start, stop, step = param_args
				for value in numpy.linspace(start, stop,
					points_in_range(start, stop, step)
				):
					yield param, value
			elif scan_type == '--linearN':
				start, stop, N = param_args
				for value in numpy.linspace(start, stop, N):
					yield param, value
			# exponential scan
			elif scan_type == '--exp':
				start, stop, step = param_args
				for value in numpy.linspace(start, stop,
					points_in_range(start, stop, step)
				):
					yield param, 10**value
			elif scan_type == '--expN':
				start, stop, N = param_args
				for value in numpy.linspace(start, stop, N):
					yield param, 10**value
			# random scan (uniform)
			elif scan_type == '--random':
				low, high, count = param_args
				for _ in range(count):
					yield param, random.uniform(low, high)
			# random scan (any distribution)
			elif scan_type == '--random-dist':
				dist_name, count = param_args[:2]
				dist_args = param_args[2:]
				for _ in range(count):
					yield param, getattr(random, dist_name)(*dist_args)
			else:
				raise ValueError('Unknown scan type')

def param_values_random():
	res = {}
	for _ in range(args.random_points):
		for scan_opts in args.random_scan:
			random_val = first_param_value(scan_opts)
			res[scan_opts.param] = random_val
		yield res
	# yield empty dict if not using --random-points
	if not args.random_points: yield {}

def number_of_points(scan_opts):
	scan_type = scan_opts.scan_type
	param_args = scan_opts.options
	if scan_type == '--set':
		return len(param_args)
	elif scan_type in ('--linear', '--exp'):
		start, stop, step = param_args
		return points_in_range(start, stop, step)
	elif scan_type in ('--linearN', '--expN', '--random'):
		_, _, N = param_args
		return N
	elif scan_typ == '--random-dist':
		return param_args[1]
	else:
		raise ValueError('Unknown scan type')

# create a dictionary mapping parameters to the values/ranges to use
params = collections.OrderedDict()
for scan_opts in args.param_scan:
	if not params.has_key(scan_opts.param):
		params[scan_opts.param] = []
	params[scan_opts.param].append(scan_opts)

# process conditions
model = MODELS[MODEL_NAME]
conditions = []
for condition in args.condition:
	for param_name in model.params:
		condition = re.sub(
			r'\b({})\b(\[\s*\d+(,\s*\d+\s*)*\])?'.format(param_name),
			r'model.param_value(parse_param("\g<0>"))', condition
		)
	conditions.append(condition)
# set paths
tmp_path = tempfile.mkdtemp(prefix='micromegas.')
run_info_path = os.path.join(tmp_path, RUN_INFO_FILE)
spheno_in_path = os.path.join(tmp_path, SPHENO_INPUT_FILE)
spheno_out_path = os.path.join(tmp_path, SPHENO_OUTPUT_FILE)
# write run information file
with open(run_info_path, 'w') as f:
	print('#', ' '.join(sys.argv), file=f)
# start the micrOMEGAs process
micromegas_path = os.path.join(MICROMEGAS_DIR, MODEL_NAME, MICROMEGAS_EXE)
print('Starting micrOMEGAs binary at {}'.format(micromegas_path))
print('Using temporary directory {}'.format(tmp_path))
micromegas = subprocess.Popen(
	[micromegas_path, tmp_path],
	stdin=subprocess.PIPE, stdout=subprocess.PIPE,
	# text mode, unbuffered
	universal_newlines=True, bufsize=0
)

# user information and prompt
print('Number of points to be scanned: {:,}'.format(
	reduce(operator.mul, (number_of_points(scan_opts)
			for scan_opts in args.param_scan + args.random_scan
		), 1
	)
))
if args.skip > 0:
	print('Of these, the first {:,} will be skipped'.format(args.skip))
input('[Press ENTER to start]\n')
# perform the parameter scan
param_idx = 0
for values in itertools.product(*(list(g)
	for k, g in itertools.groupby(param_values(params), key=lambda tup: tup[0])
)):
	# set parameters
	for param, value in values:
		model.set_param_value(param, value)
	for random_values in param_values_random():
		# set random parameters
		for param, value in random_values.items():
			model.set_param_value(param, value)
		# skip point if specified condition is not met
		if not all(safe_eval(cond, {'model': model}) for cond in conditions):
			continue
		param_idx += 1
		# skip args.skip points
		if param_idx <= args.skip:
			continue
		print('data point #{}'.format(param_idx))
		# generate SLHA input file
		pyslha.write(spheno_in_path, DOC)
		# Add a comment at the end of every line – the SARAH-generated version
		# of SPheno requires this!
		# see http://stauby.de/sarah_userforum/viewtopic.php?f=4&t=49
		subprocess.check_call(['sed', '-i',
			'-e', '/^$/d',   # remove empty lines (so comments won’t be added)
			'-e', 's/$/ #/', # add “ #” at the end of every line
			spheno_in_path
		])
		# run SPheno, aborting if SPheno exits with an error (e.g. when
		# catching SIGINT)
		# XXX check if there was an error during SPheno calculations
		#     (SPheno does not set status code if no output file is produced?)
		subprocess.check_call([
			os.path.join(SPHENO_DIR, 'bin', 'SPheno{}'.format(MODEL_NAME)),
			spheno_in_path, spheno_out_path
		])
		# signal to the micrOMEGAs process that the SPheno spectrum file is
		# ready (could be any message of length 1 byte)
		micromegas.stdin.write('S')
		# read from micrOMEGAs stdout to check when it is done with this file
		stdout_closed = False
		line = ''
		while not (stdout_closed or '=' * 20 in line):
			line = micromegas.stdout.readline()
			print(line, end='')
			stdout_closed = not line
		if stdout_closed: break

