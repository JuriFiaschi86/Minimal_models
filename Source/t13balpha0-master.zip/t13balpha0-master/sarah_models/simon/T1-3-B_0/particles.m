ParticleDefinitions[GaugeES] = {
	(* new fields *)
	{phip, {Description -> "BSM field ϕ+",
			LaTeX -> "\\phi^+",
			OutputName -> "phip",
			ElectricCharge -> 1
		}
	},
	{phi0, {Description -> "BSM field ϕ0",
			LaTeX -> "\\phi^0",
			OutputName -> "phi0",
			ElectricCharge -> 0
		}
	},

	{CPsi0, {Description -> "BSM field Ψ0",
			LaTeX -> "\\Psi^0",
			OutputName -> "CPsi0",
			ElectricCharge -> 0
		}
	},
	{psipp, {Description -> "BSM field ψ'+",
			LaTeX -> "\\psi'^+",
			OutputName -> "psipp",
			ElectricCharge -> 1
		}
	},
	{psip0, {Description -> "BSM field ψ'0",
			LaTeX -> "\\psi'^0",
			OutputName -> "psip0",
			ElectricCharge -> 0
		}
	},
	{psi0, {Description -> "BSM field ψ0",
			LaTeX -> "\\psi^0",
			OutputName -> "psi0",
			ElectricCharge -> 0
		}
	},
	{psim, {Description -> "BSM field ψ-",
			LaTeX -> "\\psi^-",
			OutputName -> "psim",
			ElectricCharge -> -1
		}
	},

	(* Standard Model *)
	{H0, {
			PDG -> {0},
			Width -> 0,
			Mass -> Automatic,
			FeynArtsNr -> 1,
			LaTeX -> "H^0",
			OutputName -> "H0"
		}
	},
	{Hp, {
			PDG -> {0},
			Width -> 0,
			Mass -> Automatic,
			FeynArtsNr -> 2,
			LaTeX -> "H^+",
			OutputName -> "Hp"
		}
	},

	{VB,  {Description -> "B-Boson"}},
	{VG,  {Description -> "Gluon"}},
	{VWB, {Description -> "W-Bosons"}},
	{gB,  {Description -> "B-Boson Ghost"}},
	{gG,  {Description -> "Gluon Ghost"}},
	{gWB, {Description -> "W-Boson Ghost"}}
};

ParticleDefinitions[EWSB] = {
	(* new fields *)
	(* to be completed manually *)
	{phip, {Description -> "BSM field ϕ+",
			LaTeX -> "\\phi^+",
			OutputName -> "php",
			PDG -> {901},
			FeynArtsNr -> 901,
			ElectricCharge -> 1
		}
	},
	{phi0, {Description -> "BSM field ϕ0",
			LaTeX -> "\\phi^0",
			OutputName -> "ph0",
			PDG -> {902},
			FeynArtsNr -> 902,
			ElectricCharge -> 0
		}
	},

	{Fpsi, {Description -> "BSM charged (-1) Dirac spinor Fψ",
			LaTeX -> "\\psi",
			OutputName -> "psi",
			PDG -> {903},
			FeynArtsNr -> 903,
			ElectricCharge -> -1
		}
	},
	{Fchi, {Description -> "BSM neutral Majorana spinor Fχ",
			LaTeX -> "\\chi",
			OutputName -> "ch",
			PDG -> {911, 912, 913},
			FeynArtsNr -> 911,
			ElectricCharge -> 0
		}
	},

	{Fnu,  {Description -> "Neutrinos",
			Mass -> LesHouches
		}
	},

	(* Standard Model *)
	{hh,   {Description -> "Higgs",
			PDG -> {25},
			PDG.IX -> {101000001}
		}
	},
	{Ah,   {Description -> "Pseudo-Scalar Higgs",
			PDG -> {0},
			PDG.IX -> {0},
			Mass -> {0},
			Width -> {0}
		}
	},
	{Hp,   {Description -> "Charged Higgs",
			PDG -> {0},
			PDG.IX -> {0},
			Width -> {0},
			Mass -> {0},
			LaTeX -> {"H^+", "H^-"},
			OutputName -> {"Hp", "Hm"},
			ElectricCharge -> 1
		}
	},

	{VP,   {Description -> "Photon"}},
	{VZ,   {Description -> "Z-Boson",
			Goldstone -> Ah
		}
	},
	{VG,   {Description -> "Gluon"}},
	{VWp,  {Description -> "W+ - Boson",
			Goldstone -> Hp
		}
	},
	{gP,   {Description -> "Photon Ghost"}},
	{gWp,  {Description -> "Positive W+ - Boson Ghost"}},
	{gWpC, {Description -> "Negative W+ - Boson Ghost"}},
	{gZ,   {Description -> "Z-Boson Ghost"}},
	{gG,   {Description -> "Gluon Ghost"}},

	{Fd,   {Description -> "Down-Quarks"}},
	{Fu,   {Description -> "Up-Quarks"}},
	{Fe,   {Description -> "Leptons"}}
};

WeylFermionAndIndermediate = {
	(* new fields *)
	{CPsi, {LaTeX -> "\\CPsi"}},
	{psip, {LaTeX -> "\\psi'"}},
	{phi, {LaTeX -> "\\phi"}},

	{chi, {LaTeX -> "\\chi"}},
	(* Standard Model *)
	{H, {
			PDG -> {0},
			Width -> 0,
			Mass -> Automatic,
			LaTeX -> "H",
			OutputName -> ""
		}
	},

	{dR,  {LaTeX -> "d_R"}},
	{eR,  {LaTeX -> "e_R"}},
	{l,   {LaTeX -> "l"}},
	{uR,  {LaTeX -> "u_R"}},
	{q,   {LaTeX -> "q"}},
	{eL,  {LaTeX -> "e_L"}},
	{dL,  {LaTeX -> "d_L"}},
	{uL,  {LaTeX -> "u_L"}},
	{vL,  {LaTeX -> "\\nu_L"}},

	{DR,  {LaTeX -> "D_R"}},
	{ER,  {LaTeX -> "E_R"}},
	{UR,  {LaTeX -> "U_R"}},
	{EL,  {LaTeX -> "E_L"}},
	{DL,  {LaTeX -> "D_L"}},
	{UL,  {LaTeX -> "U_L"}}
};
